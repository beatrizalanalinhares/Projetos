package com.example.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder> {
    Context context; //qual activit
    ArrayList<Produto> lista; //qual produto
    Adaptador.OnItemClickListener listener; //card vai ser clicado

    public Adaptador(Context context, ArrayList<Produto> lista, OnItemClickListener listener) {
        this.context = context;
        this.lista = lista;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Adaptador.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout, parent, false); //(R.layout.layout) - caminho
        return new Adaptador.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptador.MyViewHolder holder, int position) { // pegar a posição do card e deixar clicavel
     Produto p = lista.get(position);
     holder.nome.setText(p.getNome());
     holder.tipo.setText(p.getTipo());
     holder.preco.setText("R$ "+p.getPreco());
     holder.itemView.setOnClickListener(view ->{
         listener.onItemClick(p); //possibilidade de clicar
     }); // (->{}) vai executar um método dentro da chave
    }

    @Override
    public int getItemCount() { //quantos card vai aparecer
        return lista.size();
    }


    public interface OnItemClickListener {
        void onItemClick(Produto p); //quando clicar em um card retornar produto

        //produto é o objeto(conversa do wtt)
        // holder é card
    }


    public class MyViewHolder extends RecyclerView.ViewHolder { //vincular xml com produto
        TextView nome, tipo, preco;
        public MyViewHolder (@NonNull View itemView) {
            super(itemView);
            nome = itemView.findViewById(R.id.nome);
            tipo = itemView.findViewById(R.id.tipo);
            preco = itemView.findViewById(R.id.preco);
        }
        // itemview é o card
    }

}
