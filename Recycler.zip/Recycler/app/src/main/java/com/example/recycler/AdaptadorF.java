package com.example.recycler;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class AdaptadorF extends FragmentStateAdapter {

    public AdaptadorF(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }


    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) { //swith = escolha
            case 1: //caso seja 1
                return new Lista();
        }
        //diferença de swith e if, switch usa menos processamento
        return new Cadastro(); //retorne primeiro
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
