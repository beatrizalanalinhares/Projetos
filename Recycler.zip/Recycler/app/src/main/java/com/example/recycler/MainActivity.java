package com.example.recycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ViewPager2 pager;
    TabLayout tab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        AdaptadorF adaptadorF = new AdaptadorF(getSupportFragmentManager(), getLifecycle());
        pager = findViewById(R.id.pager);
        tab = findViewById(R.id.tab);
        pager.setAdapter(adaptadorF); //alterar adaptador no pager

        tab.addTab(tab.newTab().setText("Novo produto")); //adicionar tab e mudar texto pra primeiro
        tab.addTab(tab.newTab().setText("Produtos"));//adicionar tab e mudar texto

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { //comando para dar função pra tab
            @Override
            public void onTabSelected(TabLayout.Tab tab) { //selecionar guia
                pager.setCurrentItem(tab.getPosition()); //deixar a tab na mesma posição que o pager
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            } //deselecionar guia

            @Override
            public void onTabReselected(TabLayout.Tab tab) { //selecionar de novo guia

            }
        });
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() { //comando para dar função ao pager
            @Override
            public void onPageSelected(int position) { //ao selecionar pager muda posição
                super.onPageSelected(position);
                tab.selectTab(tab.getTabAt(position)); //mudar tab quando mudar pager
            }
        });
    }

}