package com.example.recycler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TelaProduto extends AppCompatActivity {
    static Produto p;
    EditText nome, tipo, preco;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_produto);
        getSupportActionBar().hide();
        nome = findViewById(R.id.nome);
        tipo = findViewById(R.id.tipo);
        preco = findViewById(R.id.preco);

        nome.setText(p.getNome());
        tipo.setText(p.getTipo());
        preco.setText(p.getPreco()+"");
    }

    public void atualiza(View v) {
        deletar();
        String n = nome.getText().toString();
        String t = tipo.getText().toString();
        float pr = Float.parseFloat(preco.getText().toString());
        Produto p = new Produto(n,t,pr);
        p.salvar();
        super.onBackPressed();
    }
    public void excluir(View v) {
        deletar();
        super.onBackPressed();
    }
    public void deletar(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Produtos").child(p.getNome()).removeValue();
        super.onBackPressed();
    }
}