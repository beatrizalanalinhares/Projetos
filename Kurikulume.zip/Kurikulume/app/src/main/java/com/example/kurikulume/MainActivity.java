package com.example.kurikulume;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    TabLayout tab;
    ViewPager2 pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        tab = findViewById(R.id.tab);
        pager = findViewById(R.id.pager);

        FragmentManager fm = getSupportFragmentManager(); //chamando gerente
        Adaptador Adaptador = new Adaptador (fm, getLifecycle());

        pager.setAdapter(Adaptador); //alterar adaptador no pager
        //tab.addTab(tab.newTab().setText("Cadastro")); //adicionar tab e mudar texto
        //tab.addTab(tab.newTab().setText("Layout"));//adicionar tab e mudar texto

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { //comando para dar função pra tab
            @Override
            public void onTabSelected(TabLayout.Tab tab) { //selecionar guia
                pager.setCurrentItem(tab.getPosition()); //deixar a tab na mesma posição que o pager
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }

        });
                pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() { //comando para dar função ao pager
                    @Override
                    public void onPageSelected(int position) { //ao selecionar pager muda posição
                        super.onPageSelected(position);
                        tab.selectTab(tab.getTabAt(position)); //mudar tab quando mudar pager
    }
});
    }
}





